import RPi.GPIO as GPIO
import time

class distanciaCls ():
    def __init__(self, trigger, echo):
        self.trigger = trigger
        self.echo = echo
        self.maxTimeWait = 0.005
        self.peripheral_setup()
    
    def peripheral_setup (self) :
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
    
        GPIO.setup(self.trigger,GPIO.OUT)
        GPIO.setup(self.echo,GPIO.IN)

    # Se toma la distancia si pasado un tiempo no detecta sale
    def getDistancia(self):
        try:
            tStart = time.time()
            GPIO.output(self.trigger, True)
            time.sleep(0.00001)
            GPIO.output(self.trigger, False)

            while GPIO.input(self.echo)==0:
                pulse_start = time.time()
                if pulse_start - tStart > self.maxTimeWait:
                    return None
            while GPIO.input(self.echo)==1:
                pulse_end = time.time()
            
            return round((pulse_end - pulse_start) * 17150, 2)
        except:
            return None
        

