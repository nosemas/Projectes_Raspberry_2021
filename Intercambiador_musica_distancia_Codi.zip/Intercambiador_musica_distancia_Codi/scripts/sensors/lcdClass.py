
import RPi.GPIO as GPIO
import time

class lcdCLS ():
    def __init__(self, listPinesEntrada):
        # GPIO to LCD mapping
        self.LCD_RS = listPinesEntrada[0] # 7 # Pi pin 26
        self.LCD_E =  listPinesEntrada[1] # 8 # Pi pin 26# Pi pin 24
        self.LCD_D4 = listPinesEntrada[2] #25 # Pi pin 22
        self.LCD_D5 = listPinesEntrada[3] #24 # Pi pin 18
        self.LCD_D6 = listPinesEntrada[4] #23 # Pi pin 16
        self.LCD_D7 = listPinesEntrada[5]  #18 # Pi pin 12
        
        # Device constants
        self.LCD_CHR = True # Character mode
        self.LCD_CMD = False # Command mode
        self.LCD_CHARS = 16 # Characters per line (16 max)
        self.LCD_LINE_1 = 0x80 # LCD memory location for 1st line
        self.LCD_LINE_2 = 0xC0 # LCD memory location 2nd line
        
        GPIO.setwarnings(False) 
        GPIO.setmode(GPIO.BCM) # Use BCM GPIO numbers
        GPIO.setup(self.LCD_E, GPIO.OUT) # Set GPIO's to output mode
        GPIO.setup(self.LCD_RS, GPIO.OUT)
        GPIO.setup(self.LCD_D4, GPIO.OUT)
        GPIO.setup(self.LCD_D5, GPIO.OUT)
        GPIO.setup(self.LCD_D6, GPIO.OUT)
        GPIO.setup(self.LCD_D7, GPIO.OUT)
        self.lcd_init()
        # Initialize and clear display
    def lcd_init(self):
        self.lcd_write(0x33,self.LCD_CMD) # Initialize
        self.lcd_write(0x32,self.LCD_CMD) # Set to 4-bit mode
        self.lcd_write(0x06,self.LCD_CMD) # Cursor move direction
        self.lcd_write(0x0C,self.LCD_CMD) # Turn cursor off
        self.lcd_write(0x28,self.LCD_CMD) # 2 line display
        self.lcd_write(0x01,self.LCD_CMD) # Clear display
        time.sleep(0.0005) # Delay to allow commands to process

    def lcd_write(self, bits, mode):
        # High bits
        GPIO.output(self.LCD_RS, mode) # RS

        GPIO.output(self.LCD_D4, False)
        GPIO.output(self.LCD_D5, False)
        GPIO.output(self.LCD_D6, False)
        GPIO.output(self.LCD_D7, False)
        if bits&0x10==0x10:
            GPIO.output(self.LCD_D4, True)
        if bits&0x20==0x20:
            GPIO.output(self.LCD_D5, True)
        if bits&0x40==0x40:
            GPIO.output(self.LCD_D6, True)
        if bits&0x80==0x80:
            GPIO.output(self.LCD_D7, True)
            
        # Toggle 'Enable' pin
        self.lcd_toggle_enable()

        # Low bits
        GPIO.output(self.LCD_D4, False)
        GPIO.output(self.LCD_D5, False)
        GPIO.output(self.LCD_D6, False)
        GPIO.output(self.LCD_D7, False)
        if bits&0x01 == 0x01:
            GPIO.output(self.LCD_D4, True)
        if bits&0x02 == 0x02:
            GPIO.output(self.LCD_D5, True)
        if bits&0x04 == 0x04:
            GPIO.output(self.LCD_D6, True)
        if bits&0x08 == 0x08:
            GPIO.output(self.LCD_D7, True)

        # Toggle 'Enable' pin
        self.lcd_toggle_enable()
    
    def lcd_toggle_enable(self):
        time.sleep(0.0005)
        GPIO.output(self.LCD_E, True)
        time.sleep(0.0005)
        GPIO.output(self.LCD_E, False)
        time.sleep(0.0005)
    def getLine (self, line):
        if line == 1:
            return self.LCD_LINE_1
        else:
            return self.LCD_LINE_2
        
    def lcd_text(self, message, line):
        # Send text to display
        message = message.ljust(self.LCD_CHARS," ")

        self.lcd_write(self.getLine(line), self.LCD_CMD)

        for i in range(self.LCD_CHARS):
            self.lcd_write(ord(message[i]),self.LCD_CHR)    
    
    def entradaToogle (self, text, linea, direccion): # direccion true Derecha o false Izquierda 
        textoActual = ''
        lenTexto = len(text)
        if direccion == True: 
            for pos in range(lenTexto - 1, -1, -1):
                textoActual = text[pos] + textoActual
                self.lcd_text(textoActual, linea)
                time.sleep(0.001)
        else:
            textoActual = ' ' * 16
            indTexto = 0
            for pos in range(17, -1, -1):
                if indTexto < len(text):
                    text = text[1:] + text[indTexto]
                    self.lcd_text(textoActual, linea)
                else:
                    text = text[1:] + ' '
                    self.lcd_text(textoActual, linea)
                indTexto += 1
                    
            
        time.sleep(1)   
        #self.lcd_text('', linea)
        
    def salidaToogle (self, text, linea, direccion): # direccion true Derecha o false Izquierda
        if direccion == True:
            for pos in range(17):
                text = " " + text
                self.lcd_text(text, linea)
                time.sleep(0.001)
        else:
            lenTexto = len(text)
            
            for pos in range(len(text)):
                text = text[1:] + " "
                print('texto')
                print(text)
                self.lcd_text(text, linea)
        time.sleep(0.1)   
         
'''
lcd1 = lcdCLS([7,8,25, 24,23,18])
count = 0
linea = 1
while 1:
    count += 1
    lcd1.entradaToogle('HOLA {}'.format(count), linea, False)
    #lcd1.lcd_text('HOLA {}'.format(count), linea)
    lcd1.salidaToogle('HOLA {}'.format(count), linea, True)
    if linea == 1:
        linea = 2
    else:
        linea = 1
    lcd1.lcd_text('', linea)
    #time.sleep(0.5)

'''