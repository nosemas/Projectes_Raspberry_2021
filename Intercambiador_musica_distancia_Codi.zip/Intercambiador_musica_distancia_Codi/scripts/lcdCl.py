from scripts.sensors.lcdClass import lcdCLS as lcdCLS

class lcdCl (lcdCLS):
    def __init__(self, listPinesEntrada):
        lcdCLS.__init__(self, listPinesEntrada)

    def textoSimple(self, text, line):
        super().lcd_text(text, line)
    
    def entradaTextoTg (self, text, linea, direccion):
        super().entradaToogle (text, linea, direccion)
    
    def clearLineTG(self, text, linea, direccion):
        super().salidaToogle (self, text, linea, direccion)
    
    def clearLCD(self):
        super().textoSimple('', 1)
        super().textoSimple('', 2)
        
    