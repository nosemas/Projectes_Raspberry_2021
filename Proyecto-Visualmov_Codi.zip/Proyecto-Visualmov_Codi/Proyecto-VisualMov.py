import RPi.GPIO as GPIO
import time
import picamera
import os
from datetime import datetime
from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive


pinPir = 18 #sensor HC-SR501
pinLed = 23 #LED


#Función de configuración que la RaspBerry Pi: 
#GPIO18 -> actividad del sensor de movimiento HC-SR501
#GPIO23 -> on/off LED
def config_periferico():
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
    GPIO.setup(pinPir, GPIO.IN)
    GPIO.setup(pinLed, GPIO.OUT)    


#Recuperamos datos de fecha y hora de sistema para darle formato a nombre archivo de imagen
def recupera_datetime():
    ahora = datetime.now()
    dia = ahora.day
    mes = ahora.month
    ano = ahora.year
    hora = ahora.hour
    minuto = ahora.minute
    segundo = ahora.second
    return dia, mes, ano, hora, minuto, segundo
    

#Función que eliminará la carpeta generada hace un mes con todo su contenido.
#Si la carpeta no existe muestra mensaje y sale de la función
def borrar_carpeta(carpeta):
    borrar_carpeta_OS = "rm -r {}".format(carpeta)
    if os.path.isdir(carpeta):
        os.system(borrar_carpeta_OS)
        print("··· La carpeta '{}' ha sido eliminada satisfactoriamente.".format(carpeta))
        time.sleep(2)
    else:
        print("··· No se ha encontrado la carpeta '{}' para su eliminación.".format(carpeta))
        time.sleep(2)


def eliminar_carpeta():
    d, me, a, h, mi, s = recupera_datetime()
    #permite eliminar las carpetas que se generaron en diciembre (mes 12) del año anterior.
    if me == 1:
        m_anterior = 12
        a_anterior = a - 1
        b_carpeta = "PVM_IMAGES{:02d}-{:02d}-{:02d}".format(d, m_anterior, a_anterior)
        borrar_carpeta(b_carpeta)
    #permite  eliminar, el dia 2 de marzo, las carpetas generadas los dias 29, 30, 31 del mes de enero
    #puesto que febrero no dispone de estos días, excepto el 29 de año bisiesto.
    #también eliminará la carpeta del 2 de febrero.
    elif(me == 3 and d == 2):
        d_enero = [29, 30, 31]
        for d_e in d_enero:
            b_carpeta_e = "PVM_IMAGES{:02d}-{:02d}-{:02d}".format(d_e, 1, a)
            borrar_carpeta(b_carpeta_e)
        b_carpeta_f = "PVM_IMAGES{:02d}-{:02d}-{:02d}".format(d, 2, a)
        borrar_carpeta(b_carpeta_f)
    #permite eliminar las carpetas de los días 31 de los pertinentes meses (marzo, mayo, agosto, octubre)
    #junto a las carpetas del día 30
    elif ((me == 4 or me == 6 or me == 9 or me == 11) and (d == 30)):
        m_anterior = me - 1
        b_carpeta1 = "PVM_IMAGES{:02d}-{:02d}-{:02d}".format(d, m_anterior, a)
        b_carpeta2 = "PVM_IMAGES{:02d}-{:02d}-{:02d}".format(31, m_anterior, a)
        print("··· Se borrarán las carpetas del día 30 y 31 del mes anterior.")
        borrar_carpeta(b_carpeta1)
        borrar_carpeta(b_carpeta2)
    #permite eliminar todas las carpetas que no dispongan de 'atributo' especial.
    #tanto el dia 31 de julio como el 31 de diciembre, entran en este último supuesto
    #dado que sus meses siguientes respectivamente también disponen de 31 días (agosto y enero)     
    else:
        m_anterior = me - 1
        b_carpeta = "PVM_IMAGES{:02d}-{:02d}-{:02d}".format(d, m_anterior, a)
        borrar_carpeta(b_carpeta)
    
    
#Función que crea la carpeta que contendrá las imagenes capturadas durante las 24h de
#un día específico.   
def generar_carpeta_archivo():
    d, me, a, h, mi, s = recupera_datetime()
    n_c = "PVM_IMAGES{:02d}-{:02d}-{:02d}".format(d, me, a)#nombre carpeta
    r_a = "{}/PVMImg{:02d}{:02d}{:02d}{:02d}{:02d}{:02d}.jpg".format(n_c, d, me, a, h, mi, s)#ruta(carpeta) y archivo de imagen jpg que se crea en el sistema
    genera_carpeta = "mkdir {}".format(n_c) #comando OS para crear carpeta
    if os.path.isdir(n_c): #verifica si existe la carpeta
        pass
    else: 
        os.system(genera_carpeta)#método que permite ejecutar el comando OS
        print("··· La carpeta '{}' se ha creado satisfactoriamente.".format(n_c))
            
    return r_a
       
   
#Función que permitirá subir las imagenes generadas al Google Drive
#Autenticación:
#client_secrets.json -> datos de id_cliente y secreto_cliente de OAuth 2.0
#settings.yaml -> registramos los datos de cliente OAuth
#quickstart.py -> genera archivo de credenciales (credencial.json)
def subir_googleDrive(ruta_archivo):
    id_carpetaDrive = "1HnOpLf9GbwxMRmJWofIqZklxiiaeA_q7"
    autenticacion = GoogleAuth()
    autenticacion.LocalWebserverAuth()
    drive = GoogleDrive(autenticacion)    
    archivoDrive = drive.CreateFile({'parents': [{'kind': 'drive#fileLink', 'id': id_carpetaDrive}]})
    archivoDrive['title'] = ruta_archivo.split('/')[-1]
    archivoDrive.SetContentFile(ruta_archivo)
    archivoDrive.Upload()


#Función que inicializa la cámara, captura la imagen, la detiene y la cierra. Finalmente,
#el archivo generado lo publicacrá en la cuenta de Google Drive
def disparo_camara():    
    with picamera.PiCamera() as mi_imagen:
        mi_imagen.start_preview()
        cont_imagen = 0
        while cont_imagen < 10:
            nombre_archivo = generar_carpeta_archivo()
            print("··· Capturando imagen en -> '{}.".format(nombre_archivo))
            mi_imagen.capture(nombre_archivo)
            cont_imagen += 1
            time.sleep(0.5)
            try:
                subir_googleDrive(nombre_archivo)
                print("··· Archivo subido a Google Drive.")
            except Exception as e:
                print("··· No se ha completado la subida del archivo.")
                print("··· eRROR: {}".format(e))
        mi_imagen.stop_preview()
        mi_imagen.close()    


#Función que recupera actividad del sensor y dispara la cámara
def comprobar_movimiento():
    if GPIO.input(pinPir):
        print("··· Sensor HC-SR501: Movimiento detectado.")
        GPIO.output(pinLed, GPIO.HIGH)
        disparo_camara()
        GPIO.output(pinLed, GPIO.LOW)
    else: 
        print("··· Sensor HC-SR501: No se detecta movimiento.")
        

def main():
    config_periferico()
    eliminar_carpeta()
    try:
        while True:
            print("··· Sensor HC-SR501: Esperando resolución.")
            time.sleep(2)
            comprobar_movimiento()
    
    except Exception as e_error:
        print("eRROR: {}".format(e_error))
    
    finally:
        print("··· Fin de la ejecución.")
        GPIO.cleanup()
            

if __name__ == '__main__':
    main()
