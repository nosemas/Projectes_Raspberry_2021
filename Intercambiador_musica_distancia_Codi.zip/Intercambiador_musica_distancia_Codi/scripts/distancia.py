from scripts.sensors.distanciaClass import distanciaCls as senDist

class distancia(senDist):
    def __init__(self, pinTrigger, pinEcho):
         senDist.__init__(self, pinTrigger, pinEcho)

    def distancia(self):
        return super().getDistancia()