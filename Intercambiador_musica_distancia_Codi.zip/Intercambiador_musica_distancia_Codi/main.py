# imports
import scripts.distancia as senDistancia
import scripts.lcdCl as lcdC
import scripts.buzzer as buzzer
import scripts.csv as csv
import time
import copy
####################
# pines 
####################
# Sensor distancia 1
trigPin1 = 26
echoPin1 = 19
# Sensor distancia 2
trigPin2 = 13
echoPin2 = 6
# Sensor distancia 3
trigPin3 = 5
echoPin3 = 11
# Sensor distancia 4
trigPin4 = 9
echoPin4 = 10
# Sensor distancia 5
trigPin5 = 22
echoPin5 = 27

# LCD
LCD_RS = 21
LCD_E = 20
LCD_D4 = 16
LCD_D5 = 7
LCD_D6 = 8
LCD_D7 = 25
lstPinesLcd = [LCD_RS, LCD_E, LCD_D4, LCD_D5, LCD_D6, LCD_D7]

# buzzer 1
pinBuzz1 = 4
pinBuzz2 = 23
pinBuzz3 = 18
pinBuzz4 = 15
pinBuzz5 = 14

###############################
# instancias de sensores, lcd y buzzers
###############################
# sensor distancia
sDistancia1 = senDistancia.distancia(trigPin1, echoPin1)
sDistancia2 = senDistancia.distancia(trigPin2, echoPin2)
sDistancia3 = senDistancia.distancia(trigPin3, echoPin3)
sDistancia4 = senDistancia.distancia(trigPin4, echoPin4)
sDistancia5 = senDistancia.distancia(trigPin5, echoPin5)
# LCD
display = lcdC.lcdCl(lstPinesLcd)
# Buzzers
buzzer1 = buzzer.buzzer(pinBuzz1)
buzzer2 = buzzer.buzzer(pinBuzz2)
buzzer3 = buzzer.buzzer(pinBuzz3)
buzzer4 = buzzer.buzzer(pinBuzz4)
buzzer5 = buzzer.buzzer(pinBuzz5)


# base de datos de las notas Notas
csvNotas = csv.csv('./scripts/notas.csv')
#notas = csvNotas.getInfo()

if (sDistancia1.distancia() != None):
    distancia1ini = int(sDistancia1.distancia())
else:
    distancia1ini = sDistancia1.distancia()

if (sDistancia2.distancia() != None):
    distancia2ini = int(sDistancia2.distancia())
else:
    distancia2ini = sDistancia2.distancia()
    

nota = ""
notAbc = ""
notaFrec = 0

nota2 = ""
notAbc2 = ""
notaFrec2 = 0

alturaMaxima = 100 # Altura máxima para que suene 

while True:
    try:
    ########## CANAL 1 ############################################    
        distancia1 = sDistancia1.distancia()
        
        if distancia1 != None:
            distancia1 = int(distancia1)
            if distancia1 < alturaMaxima and distancia1 > 0: # Dentro de los parámetros de distancia
                if distancia1 + 2 == distancia1ini or distancia1 - 2 == distancia1ini or distancia1 == distancia1ini:
                    pass # No ha cambiado la posición de la mano
                else:
                    
                    notFrec = csvNotas.getNota('C5', distancia1)
                    
                    notaFrec = int(notFrec[1])
                    notAbc = notFrec[0]
                    
                    sonFrec = csvNotas.getSonFrec('C1', distancia1)
                    
                    #buzzer1.iniciarSonido(notaFrec) # inicia sonido
                    buzzer1.iniciarSonido(sonFrec) # inicia sonido
                    distancia1ini = copy.deepcopy(distancia1) # guarda la distandia
            else:
                buzzer1.pararSonido()   
                
                display.textoSimple ("C5: N/D", 0)          
            display.textoSimple ("C5: {} {} ->".format(notAbc, notaFrec / 2), 0)
            #display.textoSimple ("=" * distancia1, 1)  
        else:
            buzzer1.pararSonido()
        
    ############ CANAL 2 #############################################
            
        distancia2 = sDistancia2.distancia()
        print ("Distancia2: {}".format(distancia2))
    
        if distancia2 != None:
            distancia2 = int(distancia2)
            if distancia2 < 100 and distancia2 > 0:
                
                if distancia2 + 2 == distancia2ini or distancia2 - 2 == distancia2ini or distancia2 == distancia2ini:
                    pass
                else:
                    notFrec2 = csvNotas.getNota('C3', distancia2)
                    print(notFrec2)
                    notaFrec2 = int(notFrec2[1])
                    notAbc2 = notFrec2[0]
                    print(notaFrec2)
                    print(notAbc2)
                    sonFrec2 = csvNotas.getSonFrec('C2', distancia2)
                    
                    #buzzer2.iniciarSonido(notaFrec2)#(csvNotas.getNota('C4', distancia2))
                    buzzer2.iniciarSonido(sonFrec2)#(csvNotas.getNota('C4', distancia2))
                    distancia2ini = copy.deepcopy(distancia2)
            else:
                buzzer2.pararSonido()         
            display.textoSimple ("C3: {} {} ->".format(notAbc2, notaFrec2 / 2), 1)
            #display.textoSimple ("=" * distancia2, 1)  
        else:
            buzzer2.pararSonido()
    except:
        pass
