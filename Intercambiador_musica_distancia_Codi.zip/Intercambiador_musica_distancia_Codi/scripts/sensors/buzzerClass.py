import math
import time
import RPi.GPIO as GPIO


class Buzzer():
    def __init__(self,pinEntrada):
        self.pinEntrada = pinEntrada
        self.peripheral_setup ()
        self.buzzer = GPIO.PWM(pinEntrada, 10) # Set frequency to 1 Khz
        self.started = False
        self.duty = 10
    def peripheral_setup (self) :
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
        GPIO.setup(self.pinEntrada, GPIO.OUT)

    def startBuzz(self):
        self.started = True
        self.buzzer.start(self.duty)

    def chkFrec(self, frequenzy):
        if not self.started:
            self.startBuzz()
        self.buzzer.ChangeFrequency(frequenzy)
        time.sleep(0.001)
        
    def chkDuty(self, duty):
        self.duty = duty
    def stopBuzz(self):
        self.started = False
        self.buzzer.stop()
        self.buzzer.ChangeFrequency(0.1)
        #time.sleep(1)
