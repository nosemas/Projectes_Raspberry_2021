class csv():
    def __init__(self, rutaArchivo):
        self.ruta = rutaArchivo
        self.objNotas = {"C1":[], "C2":[],
                        "C3":[], "C4":[], "C5":[]}
        self.distanciaCanal = 3 # Distancia para el cambio de nota
        self.getInfo()
    def getInfo(self):
        f = open(self.ruta, "r")
        #print(f.read())
        countLn = 0
        countC1 = 0
        countC2 = 0
        countC3 = 0
        countC4 = 0
        countC5 = 0
        for line in f:
            line = line.replace('\nB0', '')
            tmp = line.split(';')
            print('tmp: {}'.format(tmp))
            print(' t0: '+ tmp[0])
            print(' t1: '+ tmp[1])
            if tmp[0] != '' or tmp[1] != '':
                if countLn <= 11:
                    countC1 += self.distanciaCanal
                    self.objNotas["C1"].append((tmp[0],float(tmp[1].replace(',','.'))))
                else:
                    if countLn <= 23:
                        countC2 += self.distanciaCanal
                        self.objNotas["C2"].append((tmp[0],float(tmp[1].replace(',','.'))))#((tmp[0], float(tmp[1])))
                    else:
                        if countLn <= 35:
                            countC3 += self.distanciaCanal
                            self.objNotas["C3"].append((tmp[0],float(tmp[1].replace(',','.'))))#((tmp[0], float(tmp[1])))
                        else:
                            if countLn <= 47:
                                countC4 += self.distanciaCanal
                                self.objNotas["C4"].append((tmp[0], float(tmp[1].replace(',','.'))))            
                            else:
                                if countLn <= 59:
                                    countC5 += self.distanciaCanal
                                    self.objNotas["C5"].append((tmp[0], float(tmp[1].replace(',','.'))))
                countLn += 1
            
        print(self.objNotas)
        print ("Total: {}".format(countLn))
        return self.objNotas
    
    def getNota(self, canal, distancia):
        try:
            indexFrec = int(distancia / self.distanciaCanal)        
            if indexFrec > 0:
                indexFrec -= 1
            return self.objNotas[canal][indexFrec]
        except:
            pass
        
    def getSonFrec(self, canal, distancia):
        if canal == "C1":
            return (distancia * 1000) / 50
        if canal == "C2":
            return (distancia * 2000) / 50
'''
notas = csv('notas.csv')
notas.getInfo()
'''