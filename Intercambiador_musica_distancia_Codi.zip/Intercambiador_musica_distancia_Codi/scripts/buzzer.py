from scripts.sensors.buzzerClass import Buzzer as buzz

class buzzer(buzz):
    def __init__(self, pinEntrada):
        self.pinEntrada = pinEntrada
        buzz.__init__(self, pinEntrada)

    def iniciarSonido(self, frec):
        #super().startBuzz(100)
        super().chkFrec(frec)
    
    def pararSonido(self):
        super().stopBuzz()
#buzzer1 = buzzer(4)
#while True:
#    buzzer1.iniciarSonido(440)